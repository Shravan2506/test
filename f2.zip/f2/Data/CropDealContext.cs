using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using CropDealApp.Models;
using Microsoft.AspNetCore.Identity;
using System.Collections.Generic;

namespace CropDealApp.Data
{
    public class CropDealContext : IdentityDbContext
    {
        public CropDealContext(DbContextOptions<CropDealContext> options) : base(options) {}

        public DbSet<User> Users { get; set; }
        public DbSet<Bank> Banks { get; set; }
        public DbSet<Crop> Crops { get; set; }
        public DbSet<Subscription> Subscriptions { get; set; }
        public DbSet<Rating> Ratings { get; set; }
        public DbSet<Invoice> Invoices { get; set; }
        public DbSet<Cart> Carts { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            var farmerRoleId = "b8bf2706-d17f-448e-8b16-b9b2e2a16637";
            var dealerRoleId = "13d9c46d-49b7-4913-b178-68cef3c8380e";
            var adminRoleId = "21de2c35-21ad-419e-8478-91c0b15a80f5";

            var roles = new List<IdentityRole>
            {
                new IdentityRole
                {
                    Id = farmerRoleId,
                    ConcurrencyStamp = farmerRoleId,
                    Name = "Farmer",
                    NormalizedName = "Farmer".ToUpper()
                },
                new IdentityRole
                {
                    Id = dealerRoleId,
                    ConcurrencyStamp = dealerRoleId,
                    Name = "Dealer",
                    NormalizedName = "Dealer".ToUpper()
                },
                new IdentityRole
                {
                    Id = adminRoleId,
                    ConcurrencyStamp = adminRoleId,
                    Name = "Admin",
                    NormalizedName = "Admin".ToUpper()
                },
            };
            builder.Entity<IdentityRole>().HasData(roles);

            var adminUserId = "a1b2c3d4-e5f6-7890-abcd-ef1234567890";
            var hasher = new PasswordHasher<IdentityUser>();
            var adminUser = new IdentityUser
            {
                Id = adminUserId,
                UserName = "Shubham",
                NormalizedUserName = "SHUBHAM",
                Email = "shubham@gmail.com",
                NormalizedEmail = "SHUBHAM@GMAIL.COM",
                EmailConfirmed = true,
                PasswordHash = hasher.HashPassword(null, "Shubham@123"),
                SecurityStamp = string.Empty
            };

            builder.Entity<IdentityUser>().HasData(adminUser);

            var adminUserRole = new IdentityUserRole<string>
            {
                UserId = adminUserId,
                RoleId = adminRoleId
            };

            builder.Entity<IdentityUserRole<string>>().HasData(adminUserRole);

            builder.Entity<Invoice>()
                .HasOne(i => i.Dealer)
                .WithMany(u => u.Invoices)
                .HasForeignKey(i => i.User_IdDealer)
                .OnDelete(DeleteBehavior.Restrict);

            builder.Entity<Invoice>()
                .HasOne(i => i.Farmer)
                .WithMany()
                .HasForeignKey(i => i.User_IdFarmer)
                .OnDelete(DeleteBehavior.Restrict);

            // Define relationships for Cart
            builder.Entity<Cart>()
                .HasOne(c => c.Crop)
                .WithMany()
                .HasForeignKey(c => c.CropId)
                .OnDelete(DeleteBehavior.Restrict);

            builder.Entity<Cart>()
                .HasOne(c => c.Dealer)
                .WithMany()
                .HasForeignKey(c => c.UserIdDealer)
                .OnDelete(DeleteBehavior.Restrict);

            builder.Entity<Cart>()
                .HasOne(c => c.Farmer)
                .WithMany()
                .HasForeignKey(c => c.UserIdFarmer)
                .OnDelete(DeleteBehavior.Restrict);

            builder.Entity<Cart>()
                .HasIndex(c => new { c.CropId, c.UserIdDealer })
                .IsUnique();
        }
    }
}
