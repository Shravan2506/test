using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using CropDealApp.Data;
using CropDealApp.DTO;
using CropDealApp.Interface;
using CropDealApp.Models;
using CropDealApp.Service;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace CropDealApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : ControllerBase
    {
        private readonly UserManager<IdentityUser> userManager;
        private readonly IUserBankBL _userBL;
        private readonly ILogger<UserController> _logger;
        private readonly CropDealContext dbContext;

        public UserController(UserManager<IdentityUser> userManager, IUserBankBL userBL, CropDealContext dbContext, ILogger<UserController> logger)
        {
            this.userManager = userManager;
            this._userBL = userBL;
            this.dbContext = dbContext;
            this._logger = logger;
        }

        [HttpPost("AddBank")]
        [Authorize(Roles = "Farmer,Dealer")]
        public IActionResult AddBank([FromBody] BankDTO bankDTO)
        {
            var email = User.FindFirstValue(ClaimTypes.Email);
            if (string.IsNullOrEmpty(email))
            {
                return Unauthorized("User not authenticated");
            }
            _logger.LogInformation($"Adding bank details for user with email: {email}");
            bool res = _userBL.AddBank(bankDTO, email);
            if (res)
            {
                _logger.LogInformation("Bank details added successfully.");
                return Ok("Bank Details added successfully!");
            }
            else
            {
                _logger.LogWarning("Failed to add bank details.");
                return BadRequest("Failed to add BankDetails.");
            }
        }

        [HttpGet("GetBankDetails")]
        [Authorize(Roles = "Farmer,Dealer,Admin")]
        public IActionResult GetBankDetails()
        {
            var email = User.FindFirstValue(ClaimTypes.Email);
            if (string.IsNullOrEmpty(email))
            {
                return Unauthorized("User not authenticated");
            }
            _logger.LogInformation($"Fetching bank details for user with email: {email}");
            Bank res = _userBL.GetBankDetails(email);
            if (res != null)
            {
                _logger.LogInformation("Bank details fetched successfully.");
                return Ok(new { success = true, message = res });
            }
            _logger.LogWarning("No bank details found.");
            return BadRequest(new { success = false, message = res });
        }

        [HttpPatch("EditDetails")]
        [Authorize(Roles = "Farmer,Dealer")]
        public IActionResult EditBankDetails([FromBody] BankDTO bankDTO, Guid bankId)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (string.IsNullOrEmpty(userId))
            {
                return Unauthorized("User not authenticated");
            }
            _logger.LogInformation($"Editing bank details for user with ID: {userId} and bank ID: {bankId}");
            bool res = _userBL.EditBankDetails(userId, bankDTO, bankId);
            if (res)
            {
                _logger.LogInformation("Bank details edited successfully.");
                return Ok(new { success = true, message = "Edited Successfully" });
            }
            _logger.LogWarning("Failed to edit bank details.");
            return BadRequest(new { success = false, message = "Failed to edit bank details." });
        }

        [HttpDelete("DeleteBankDetails")]
        [Authorize(Roles = "Farmer,Dealer")]
        public IActionResult DeleteBankDetails(Guid bankId)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (string.IsNullOrEmpty(userId))
            {
                return Unauthorized("User not authenticated");
            }
            _logger.LogInformation($"Deleting bank details for user with ID: {userId} and bank ID: {bankId}");
            bool res = _userBL.DeleteBankDetails(userId, bankId);
            if (res)
            {
                _logger.LogInformation("Bank details deleted successfully.");
                return Ok(new { success = true, message = "Deleted Successfully" });
            }
            _logger.LogWarning("Failed to delete bank details.");
            return BadRequest(new { success = false, message = "Failed to delete bank details." });
        }
    }
}
