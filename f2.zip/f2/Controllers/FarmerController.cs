using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;
using CropDealApp.DTO;
using CropDealApp.Interface;
using CropDealApp.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using CropDealApp.Data;
namespace CropDealApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class FarmerController : ControllerBase
    {
        private readonly UserManager<IdentityUser> userManager;
        private readonly IFarmerBL _FarmerBL;
        private readonly CropDealContext dbContext;
    private readonly ILogger<FarmerController> _logger;
        public FarmerController(UserManager<IdentityUser> userManager,ILogger<FarmerController> _logger, IFarmerBL FarmerBL, CropDealContext dbContext)
        {
            this.userManager = userManager;
            this._FarmerBL = FarmerBL;
            this.dbContext = dbContext;
            this._logger=_logger;
        }

        [Authorize(Roles = "Farmer")]
        [HttpPost("AddCrop")]
        public IActionResult AddCrop([FromBody] CropDTO cropDTO)
        {
            var email = User.FindFirst(ClaimTypes.Email)?.Value;
            if (string.IsNullOrEmpty(email))
            {
                return Unauthorized("User not authenticated");
            }

            if (_FarmerBL.AddCrop(cropDTO, email))
            {
                return Ok("Crop added successfully!");
            }
            else
            {
                return BadRequest("Failed to add crop.");
            }
        }

        [Authorize(Roles = "Farmer")]
        [HttpGet("GetAllCrops")]
        public IActionResult GetCrops()
    {
        var email = User.FindFirst(ClaimTypes.Email)?.Value;
        if (string.IsNullOrEmpty(email))
        {
            return Unauthorized("User not authenticated");
        }

        List<Crop> crops = _FarmerBL.GetCrop(email);
        if (crops == null || !crops.Any())
        {
            return NotFound("No crops found.");
        }

        return Ok(new { Success = true, Message = crops });
    }


        [Authorize(Roles = "Farmer")]
        [HttpDelete("DeleteCrop")]
        public IActionResult DeleteCrop(Guid cropId)
        {
            var email = User.FindFirst(ClaimTypes.Email)?.Value;
            if (string.IsNullOrEmpty(email))
            {
                return Unauthorized("User not authenticated");
            }

            bool result = _FarmerBL.DeleteCrop(email, cropId);
            if (result)
            {
                return Ok("Crop deleted successfully!");
            }
            else
            {
                return BadRequest("Failed to delete crop.");
            }
        }


        [HttpPatch("EditCrop")]
        [Authorize(Roles = "Farmer")]
        public IActionResult EditCrop(CropDTO cropDTO, Guid cropId)
        {
            var userId = User.FindFirstValue(ClaimTypes.NameIdentifier);
            if (string.IsNullOrEmpty(userId))
            {
                return Unauthorized("User not authenticated");
            }

            bool res = _FarmerBL.EditCrop(userId, cropDTO, cropId);
            return Ok();
        }

        [Authorize(Roles ="Farmer")]
        [HttpGet("Farmer/ViewProfile")]
        public IActionResult ViewProfile(){
            var email=User.FindFirst(ClaimTypes.Email)?.Value;
            if(string.IsNullOrEmpty(email)){
                return Unauthorized("User not authenticated");
            }
            
            var profile = _FarmerBL.GetFarmerProfile(email);
            if (profile == null)
            {
                return NotFound("Farmer profile not found.");
            }

            return Ok(profile);

        }

        [Authorize(Roles ="Farmer")]
        [HttpPatch("Farmer/EditProfile")]
        public IActionResult EditProfile([FromBody] FarmerProfileDTO profileDTO){
            var email= User.FindFirst(ClaimTypes.Email)?.Value;
            if(string.IsNullOrEmpty(email)){              
                return Unauthorized("User not authenticated");
            }
            
        bool result = _FarmerBL.EditProfile(email, profileDTO);
        if (result)
        {
            return Ok("Profile updated successfully!");
        }
        else
        {
            return BadRequest("Failed to update profile.");
        }

        }
    }
}
