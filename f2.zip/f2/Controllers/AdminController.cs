using System;
using System.Security.Claims;
using System.Threading.Tasks;
using CropDealApp.Interface;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace CropDealApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AdminController : ControllerBase
    {
        private readonly UserManager<IdentityUser> userManager;
        private readonly IAdminBL _adminBL;
        private readonly ILogger<AdminController> _logger;

        public AdminController(UserManager<IdentityUser> userManager, IAdminBL adminBL, ILogger<AdminController> logger)
        {
            this.userManager = userManager;
            this._adminBL = adminBL;
            this._logger = logger;
        }

        [Authorize(Roles = "Admin")]
        [HttpGet("GetAllUsers")]
        public IActionResult GetAllUsers()
        {
            try
            {
                var users = _adminBL.GetAllUsers();
                return Ok(new { success = true, message = "All Users fetched successfully", data = users });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while fetching all users.");
                return BadRequest(new { success = false, message = ex.Message });
            }
        }

        [Authorize(Roles = "Admin")]
        [HttpDelete("DeleteUser")]
        public async Task<IActionResult> DeleteUser(string userId)
        {
            try
            {
                var role = User.FindFirstValue(ClaimTypes.Role);
                var currUserId = User.FindFirstValue(ClaimTypes.NameIdentifier);
                var result = await _adminBL.DeleteUser(userId, currUserId, role);
                return Ok(new { success = true, message = result ? "Profile deleted successfully" : "Deletion failed", data = result ? "Done" : "Something went wrong" });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while deleting user.");
                return BadRequest(new { success = false, message = ex.Message });
            }
        }

        [Authorize(Roles = "Admin")]
        [HttpGet("ActivateAccount")]
        public IActionResult ActivateAccount(string userId)
        {
            var email = User.FindFirstValue(ClaimTypes.Email);
            if (string.IsNullOrEmpty(email))
            {
                return Unauthorized("User not authenticated");
            }

            try
            {
                var (message, success) = _adminBL.ActivateAccount(userId);
                return Ok(new { success, message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while activating account.");
                return BadRequest(new { success = false, message = ex.Message });
            }
        }

        [Authorize(Roles = "Admin")]
        [HttpGet("DeactivateAccount")]
        public IActionResult DeactivateAccount(string userId)
        {
            var email = User.FindFirstValue(ClaimTypes.Email);
            if (string.IsNullOrEmpty(email))
            {
                return Unauthorized("User not authenticated");
            }

            try
            {
                var (message, success) = _adminBL.DeactivateAccount(userId);
                return Ok(new { success, message });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while deactivating account.");
                return BadRequest(new { success = false, message = ex.Message });
            }
        }
    }
}
