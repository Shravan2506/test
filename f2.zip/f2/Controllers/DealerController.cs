using System;
using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;
using CropDealApp.Data;
using CropDealApp.DTO;
using CropDealApp.Interface;
using CropDealApp.Models;
using CropDealApp.Service;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace CropDealApp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class DealerController : ControllerBase
    {
        private readonly UserManager<IdentityUser> userManager;
        private readonly IDealerBL _dealerBL;
        private readonly ILogger<DealerController> _logger;
        private readonly CropDealContext _dbContext;


        public DealerController(UserManager<IdentityUser> _userManager, IDealerBL dealerBL, ILogger<DealerController> logger,CropDealContext dbContext)
        {
            userManager = _userManager;
            _dealerBL = dealerBL;
            _logger = logger;
            _dbContext=dbContext;
        }

        [Authorize(Roles = "Dealer")]
        [HttpPost("Subscription")]
        public IActionResult AddSubscription(Guid cropId)
        {
            var email = User.FindFirst(ClaimTypes.Email)?.Value;

            if (string.IsNullOrEmpty(email))
            {
                _logger.LogWarning("User not authenticated");
                return Unauthorized("User not authenticated");
            }

            if (_dealerBL.AddSubscription(cropId, email))
            {
                _logger.LogInformation($"Subscription added successfully for cropId: {cropId}, email: {email}");
                return Ok("Subscription added successfully!");
            }
            else
            {
                _logger.LogError($"Failed to add subscription for {cropId} using {email}");
                return BadRequest("Failed to take subscription.");
            }
        }

        [Authorize(Roles = "Dealer")]
        [HttpGet("GetAllSubscriptions")]
        public IActionResult GetAllSubscriptions()
        {
            var email = User.FindFirst(ClaimTypes.Email)?.Value;

            if (string.IsNullOrEmpty(email))
            {
                _logger.LogWarning("User not authenticated");
                return Unauthorized("User not authenticated");
            }

            List<Subscription> ls = _dealerBL.GetAllSubscriptions(email);
            _logger.LogInformation($"Retrieved subscriptions for {email}");
            return Ok(new { Success = true, Message = ls });
        }

        [Authorize(Roles = "Dealer")]
        [HttpGet("GetAllCrops")]
        public IActionResult GetAllCrops()
        {
            var email = User.FindFirst(ClaimTypes.Email)?.Value;

            if (string.IsNullOrEmpty(email))
            {
                _logger.LogWarning("User not authenticated");
                return Unauthorized("User not authenticated");
            }

            List<Crop> ls = _dealerBL.GetAllCrops(email);
            _logger.LogInformation($"Retrieved all crops for {email}");
            return Ok(new { Success = true, Message = ls });
        }
        
        [Authorize(Roles = "Dealer")]
[HttpPost("PurchaseCrop/{cropId}")]
public async Task<IActionResult> PurchaseCrop(Guid cropId)
{
    var email = User.FindFirst(ClaimTypes.Email)?.Value;

    if (string.IsNullOrEmpty(email))
    {
        _logger.LogWarning("User not authenticated");
        return Unauthorized("User not authenticated");
    }

    if (await _dealerBL.PurchaseCrop(cropId, email))
    {
        _logger.LogInformation($"Crop purchased successfully for cropId: {cropId}, email: {email}");

        // Retrieve the invoice generated during the purchase
        var invoice = await _dbContext.Invoices.FirstOrDefaultAsync(i => i.Crop_Id == cropId && i.User_IdDealer == email);
        if (invoice == null)
        {
            _logger.LogError($"Invoice not found for cropId: {cropId} and email: {email}");
            return BadRequest("Invoice not found.");
        }

        _logger.LogInformation($"Invoice retrieved successfully: {invoice.Invoice_Id}");

        // Generate the PDF file path
        string path = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), $"Invoice_{invoice.Invoice_Id}.pdf");

        // Ensure the file exists before attempting to read it
        if (!System.IO.File.Exists(path))
        {
            _logger.LogError($"Invoice PDF not found at path: {path}");
            return BadRequest("Invoice PDF not found.");
        }

        // Return the PDF file in the response
        var memory = new MemoryStream();
        using (var stream = new FileStream(path, FileMode.Open, FileAccess.Read))
        {
            await stream.CopyToAsync(memory);
        }
        memory.Position = 0;

        return File(memory, "application/pdf", Path.GetFileName(path));
    }
    else
    {
        _logger.LogError($"Failed to purchase crop for cropId: {cropId} using email: {email}");
        return BadRequest("Failed to purchase crop.");
    }
}




        [Authorize(Roles = "Dealer")]
        [HttpGet("GetAllPurchases/{dealerId}")]
        public async Task<IActionResult> GetAllPurchasesAsync(string dealerId)
        {
            var email = User.FindFirst(ClaimTypes.Email)?.Value;

            if (string.IsNullOrEmpty(email))
            {
                _logger.LogWarning("User not authenticated");
                return Unauthorized("User not authenticated");
            }

            if (userManager.FindByIdAsync(dealerId).Result.Email != email)
            {
                _logger.LogWarning("Dealer ID does not match authenticated user");
                return Unauthorized("Dealer ID does not match authenticated user");
            }

            var purchases = await _dealerBL.GetAllPurchasesAsync(email);
            _logger.LogInformation($"Retrieved purchases for {email}");
            return Ok(new { Success = true, Message = purchases });
        }

        [Authorize(Roles ="Dealer")]
        [HttpGet("Dealer/ViewProfile")]
        public IActionResult ViewProfile(){
            var email=User.FindFirst(ClaimTypes.Email)?.Value;
            if(string.IsNullOrEmpty(email)){
                return Unauthorized("User not authenticated");
            }
            var profile=_dealerBL.GetDealerProfile(email);
            if(profile==null){            
            return NotFound("Dealer profile not found.");
            }

            return Ok(profile);

        }
        
        [Authorize(Roles = "Dealer")]
        [HttpPatch("EditProfile")]
        public IActionResult EditProfile([FromBody] DealerProfileDTO profileDTO)
        {
            var email = User.FindFirst(ClaimTypes.Email)?.Value;
            if (string.IsNullOrEmpty(email)){
                return Unauthorized("User not authenticated");
            }

            bool result = _dealerBL.EditProfile(email, profileDTO);
            if (result)
            {
            return Ok("Profile updated successfully!");
            }
            else
            {
                return BadRequest("Failed to update profile.");
            }
        }



        [Authorize(Roles = "Dealer")]
        [HttpPost("AddToCart")]

        public IActionResult AddToCart(Guid cropId){
            var email=User.FindFirst(ClaimTypes.Email)?.Value;
            
            if (string.IsNullOrEmpty(email))
            {
                _logger.LogWarning("User not authenticated");
                return Unauthorized("User not authenticated");
            }

            
            var result = _dealerBL.AddToCart(cropId, email);
            if (result)
            {
                _logger.LogInformation($"Crop added to cart successfully for cropId: {cropId}, email: {email}");
                return Ok("Crop added to cart successfully");
            }
            else{
                _logger.LogError($"Failed to add crop to cart for cropId: {cropId} using email: {email}");
                return BadRequest("Failed to add crop to cart.");
            }
        }

        [Authorize(Roles = "Dealer")]
        [HttpPost("GetAllCartItems")]
        public IActionResult GetAllCartItems(){
            var email=User.FindFirst(ClaimTypes.Email)?.Value;
            if(string.IsNullOrEmpty(email)){
                _logger.LogWarning("User not authenticated");
                return Unauthorized("User not authenticated");
            }

            var cartItems = _dealerBL.GetAllCartItems(email);
            if(cartItems!=null && cartItems.Any()){          
                _logger.LogInformation($"Retrieved {cartItems.Count()} cart items for email: {email}");
                return Ok(cartItems);
            }
            
            else{
                _logger.LogWarning($"No cart items found for email: {email}");
                return NotFound("No cart items found.");
            }

        }

        [Authorize(Roles ="Dealer")]
        [HttpDelete("Delete-cartItemByCropId")]
        public IActionResult DeleteCartItemByCropId(Guid cropId){
            var email=User.FindFirst(ClaimTypes.Email)?.Value;
            var result=_dealerBL.DeleteCartItemByCropId(cropId,email);
            if(!result){
                return NotFound(new { message = "User not found or cart item not found." });
            }
            return Ok(new {message="Cart Item deleted successfully"});
        }

        // RATING
        [Authorize(Roles ="Dealer")]
        [HttpPost("AddRating")]
        public IActionResult AddRating([FromBody] RatingDTO ratingDTO){
            var userIdDealer= User.FindFirstValue(ClaimTypes.NameIdentifier);
            if(string.IsNullOrEmpty(userIdDealer)){
                _logger.LogWarning("User not authenticated");
                return Unauthorized("User not authenticated");
            }
            RatingDTO rating=_dealerBL.AddRating(userIdDealer,ratingDTO);
            return Ok(new {Success=true, Message="Rating Added Successfully",data=rating});
        }
        [Authorize(Roles ="Dealer")]
        [HttpPut("EditRating")]
        public IActionResult EditRating([FromBody] RatingDTO ratingDTO){
            var userIdDealer=User.FindFirstValue(ClaimTypes.NameIdentifier);
            if(string.IsNullOrEmpty(userIdDealer)){
                return Unauthorized("User not authenticated");
            }
            RatingDTO rating=_dealerBL.EditRating(userIdDealer,ratingDTO);
            return  Ok(new{Success=true, Message="Rating edited Successfully", data =rating});

        }
        [Authorize(Roles ="Dealer")]
        [HttpGet("GetAllRatings")]
        public IActionResult GetAllRating(){
            var email = User.FindFirst(ClaimTypes.Email)?.Value;
            if(string.IsNullOrEmpty(email)){
                return Unauthorized("User not authenticated");
            }
            List<Rating> ans= _dealerBL.GetAllRating(email);
            return Ok(new{Success=true, Message="All ratings fetched Successfully", data=ans});
        }

        [Authorize(Roles ="Dealer")]
        [HttpGet("GetRatingById")]
        public IActionResult GetRatingById(Guid ratingId){
            var email=User.FindFirst(ClaimTypes.Email)?.Value;
            if(string.IsNullOrEmpty(email)){
                return Unauthorized("User not authenticated");
            }
            RatingDTO ans= _dealerBL.GetRatingById(ratingId);
            return Ok(new {Success = true, Message="Rating is fetched by Id", data =ans});
        }
        [Authorize(Roles ="Dealer")]
        [HttpDelete("DeleteRating")]
        public IActionResult DeleteRating(Guid ratingId){
            var email=User.FindFirst(ClaimTypes.Email)?.Value;
            if(string.IsNullOrEmpty(email)){
                return Unauthorized("User not authenticated");
            }
            bool ans= _dealerBL.DeleteRating(ratingId);
            if(!ans){
                return NotFound("Rating not found");
            }
            return Ok(new {Success = true, Message="Rating deleted successfully"});
        }
    }
}
