using CropDealApp.DTO;
using CropDealApp.Interface;
using CropDealApp.JwtHelper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

[Route("api/[controller]")]
[ApiController]
public class AuthController : ControllerBase
{
    private readonly IUserBL _userBL;
    private readonly IJwtTokenHelper _jwtTokenHelper;
    private readonly ILogger<AuthController> _logger;

    public AuthController(IUserBL userBL, IJwtTokenHelper jwtTokenHelper, ILogger<AuthController> logger)
    {
        _userBL = userBL ?? throw new ArgumentNullException(nameof(userBL), "UserBL should not be null");
        _jwtTokenHelper = jwtTokenHelper;
        _logger = logger;
    }

    [HttpPost("SignUp")]
    public async Task<IActionResult> Register([FromBody] SignUpDTO registerDTO)
    {
        if (registerDTO == null) return BadRequest(new { Success = false, Message = "Invalid request" });

        try
        {
            var newUser = await _userBL.RegisterBL(registerDTO);
            if (newUser == null)
            {
                return Conflict(new { Success = false, Message = "User already exists" });
            }

            return Created("user registered", new { Success = true, Message = "User registered successfully." });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error occurred during registration");
            return StatusCode(500, new { Success = false, Message = "Internal Server Error" });
        }
    }

    [HttpPost("Login")]
    public async Task<IActionResult> Login([FromBody] LoginDTO loginDTO)
    {
        if (loginDTO == null) return BadRequest(new { Success = false, Message = "Invalid request data" });

        try
        {
            var (user, token) = await _userBL.LoginBL(loginDTO);
            if (user == null || string.IsNullOrEmpty(token))
            {
                return Unauthorized(new { Success = false, Message = "Invalid username or password" });
            }

            return Ok(new { Success = true, Message = "Login Successful", Token = token });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error occurred during login");
            return StatusCode(500, new { Success = false, Message = "Internal Server Error" });
        }
    }
}
