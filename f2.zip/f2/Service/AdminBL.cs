using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using CropDealApp.Interface;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;

namespace CropDealApp.Service
{
    public class AdminBL : IAdminBL
    {
        private readonly IAdminRL _adminRL;
        private readonly ILogger<AdminBL> _logger;

        public AdminBL(IAdminRL adminRL, ILogger<AdminBL> logger)
        {
            _adminRL = adminRL;
            _logger = logger;
        }

        public List<IdentityUser> GetAllUsers()
        {
            try
            {
                return _adminRL.GetAllUsers();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while fetching all users.");
                throw;
            }
        }

        public Task<bool> DeleteUser(string userId, string currUserId, string role)
        {
            try
            {
                return _adminRL.DeleteUser(userId, currUserId, role);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while deleting user.");
                throw;
            }
        }

        public (string, bool) ActivateAccount(string userId)
        {
            try
            {
                return _adminRL.ActivateAccount(userId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while activating account.");
                throw;
            }
        }

        public (string, bool) DeactivateAccount(string userId)
        {
            try
            {
                return _adminRL.DeactivateAccount(userId);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while deactivating account.");
                throw;
            }
        }
    }
}
