using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CropDealApp.DTO;
using CropDealApp.Interface;
using CropDealApp.Models;
using Microsoft.Extensions.Logging;

namespace CropDealApp.Service
{
    public class UserBankBL : IUserBankBL
    {
        private readonly IUserBankRL _userRL;
        private readonly ILogger<UserBankBL> _logger;

        public UserBankBL(IUserBankRL user, ILogger<UserBankBL> logger)
        {
            _userRL = user;
            _logger = logger;
        }

        public bool AddBank(BankDTO bankDTO, string email)
        {
            _logger.LogInformation($"Adding bank details for user with email: {email}");
            var result = _userRL.AddBank(bankDTO, email);
            if (result)
            {
                _logger.LogInformation("Bank details added successfully.");
            }
            else
            {
                _logger.LogWarning("Failed to add bank details.");
            }
            return result;
        }

        public Bank GetBankDetails(string email)
        {
            _logger.LogInformation($"Fetching bank details for user with email: {email}");
            var result = _userRL.GetBankDetails(email);
            if (result != null)
            {
                _logger.LogInformation("Bank details fetched successfully.");
            }
            else
            {
                _logger.LogWarning("No bank details found.");
            }
            return result;
        }

        public bool DeleteBankDetails(string userId, Guid bankId)
        {
            _logger.LogInformation($"Deleting bank details for user with ID: {userId} and bank ID: {bankId}");
            var result = _userRL.DeleteBankDetails(userId, bankId);
            if (result)
            {
                _logger.LogInformation("Bank details deleted successfully.");
            }
            else
            {
                _logger.LogWarning("Failed to delete bank details.");
            }
            return result;
        }

        public bool EditBankDetails(string userId, BankDTO bankDTO, Guid bankId)
        {
            _logger.LogInformation($"Editing bank details for user with ID: {userId} and bank ID: {bankId}");
            var result = _userRL.EditBankDetails(userId, bankDTO, bankId);
            if (result)
            {
                _logger.LogInformation("Bank details edited successfully.");
            }
            else
            {
                _logger.LogWarning("Failed to edit bank details.");
            }
            return result;
        }
    }
}
