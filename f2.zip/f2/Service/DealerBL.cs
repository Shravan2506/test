using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CropDealApp.DTO;
using CropDealApp.Interface;
using CropDealApp.Models;

namespace CropDealApp.Service
{
    public class DealerBL : IDealerBL
    {
        private readonly IDealerRL _dealerRL;
        private readonly ILogger<DealerBL> _logger;

        
        public DealerBL(IDealerRL dealerRL, ILogger<DealerBL> logger)
        {
            _dealerRL = dealerRL;
            _logger = logger;
        }

        public bool AddSubscription(Guid cropId,string email){
            _logger.LogInformation("Adding subscription for cropId: {CropId}, email: {Email}", cropId, email);
            return _dealerRL.AddSubscription(cropId, email);

        }

        public List<Subscription> GetAllSubscriptions(string email){
            
            _logger.LogInformation("Getting subscriptions for email: {Email}", email);
            return _dealerRL.GetAllSubscriptions(email);
        }

        
        public List<Crop> GetAllCrops(string email)
        {     
            _logger.LogInformation("Getting all crops for email: {Email}", email);
            return _dealerRL.GetAllCrops(email);
        }

        
       public async Task<bool> PurchaseCrop(Guid cropId, string email)
        {
            _logger.LogInformation("Purchasing crop for cropId: {CropId}, email: {Email}", cropId, email);
            return await _dealerRL.PurchaseCrop(cropId, email);
        }



        
        public async Task<List<PurchaseResponseDTO>> GetAllPurchasesAsync(string email)
        {
            _logger.LogInformation("Getting all purchases for email: {Email}", email);
            return await _dealerRL.GetAllPurchasesAsync(email);
        }

        public DealerProfileDTO GetDealerProfile(string email){
            _logger.LogInformation("Get the profile for {Email}", email);
            return _dealerRL.GetDealerProfile(email);
        }

        public bool EditProfile(string email, DealerProfileDTO profileDTO){

            return _dealerRL.EditProfile(email, profileDTO);
        }

        
        public bool AddToCart(Guid cropId, string email)
        {
            _logger.LogInformation("Adding crop to cart for cropId: {CropId}, email: {Email}", cropId, email);
            return _dealerRL.AddToCart(cropId, email);
        }

        public  List<CartResponseDTO> GetAllCartItems(string email){
            _logger.LogInformation($"Getting all cart items for {email}");
            
            return _dealerRL.GetAllCartItems(email);
        }

        public bool DeleteCartItemByCropId(Guid cropId, string email){
            _logger.LogInformation($"Deleting cart items for {email}");

            return _dealerRL.DeleteCartItemByCropId(cropId,email);
        }

        // Rating

        public RatingDTO AddRating(string userId, RatingDTO ratingDTO){
            _logger.LogInformation($"Adding Rating of farmer");
            return _dealerRL.AddRating(userId,ratingDTO);
        }

        public RatingDTO EditRating(string userId,RatingDTO ratingDTO){
            return _dealerRL.EditRating(userId, ratingDTO);
        }

        public List<Rating> GetAllRating(string email){
            return _dealerRL.GetAllRating(email);
        }

        public RatingDTO GetRatingById(Guid ratingId){
            return _dealerRL.GetRatingById(ratingId);
        }       
        public bool DeleteRating(Guid ratingId){
            return  _dealerRL.DeleteRating(ratingId);
        } 

    }
}