using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CropDealApp.DTO;
using CropDealApp.Interface;
using CropDealApp.Models;
using Microsoft.Extensions.Logging;

namespace CropDealApp.Service
{
    public class FarmerBL : IFarmerBL
    {
        private readonly IFarmerRL _cropRepo;
        private readonly ILogger<FarmerBL> _logger;

        public FarmerBL(IFarmerRL cropRepo, ILogger<FarmerBL> logger)
        {
            _cropRepo = cropRepo;
            _logger = logger;
        }

        public bool AddCrop(CropDTO cropDTO, string email)
        {
            return _cropRepo.AddCropRL(cropDTO, email);
        }

        public List<Crop> GetCrop(string email)
        {
            return _cropRepo.GetCropRL(email);
        }

        public bool DeleteCrop(string userId, Guid cropId)
        {
            return _cropRepo.DeleteCrop(userId, cropId);
        }

        public bool EditCrop(string userId, CropDTO cropDTO, Guid cropId)
        {
            return _cropRepo.EditCrop(userId, cropDTO, cropId);
        }

        public FarmerProfileDTO GetFarmerProfile(string email){
            return _cropRepo.GetFarmerProfile(email);
        }
                
        public bool EditProfile(string email, FarmerProfileDTO profileDTO)
        {
            return _cropRepo.EditProfile(email, profileDTO);
        }

    }
}
