using System;
using System.Threading.Tasks;
using CropDealApp.DTO;
using CropDealApp.Interface;
using CropDealApp.Models;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Identity;

namespace CropDealApp.Service
{
    public class UserBL : IUserBL
    {
        private readonly IUser _userRL;
        private readonly IJwtTokenHelper _jwtTokenHelper;
        private readonly ILogger<UserBL> _logger;
        private readonly UserManager<IdentityUser> _userManager;

        public UserBL(IUser userRL, IJwtTokenHelper jwtTokenHelper, ILogger<UserBL> logger, UserManager<IdentityUser> userManager)
        {
            _userRL = userRL;
            _jwtTokenHelper = jwtTokenHelper;
            _logger = logger;
            _userManager = userManager;
        }

        public async Task<User> RegisterBL(SignUpDTO registerDTO)
        {
            try
            {
                var result = await _userRL.Register(registerDTO);
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred during registration");
                throw;
            }
        }

        public async Task<(User user, string token)> LoginBL(LoginDTO loginDTO)
        {
            try
            {
                var user = await _userRL.Login(loginDTO);
                if (user != null)
                {
                    var identityUser = await _userManager.FindByIdAsync(user.Id.ToString());
                    var roles = await _userManager.GetRolesAsync(identityUser);
                    _logger.LogInformation($"Roles for user {user.Id}: {string.Join(", ", roles)}");
                    var token = _jwtTokenHelper.GenerateToken(user.Id, user.Email, roles.ToList());
                    return (user, token);
                }
                return (null, null);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred during login");
                throw;
            }
        }
    }
}
