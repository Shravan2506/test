using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CropDealApp.Data;
using CropDealApp.DTO;
using CropDealApp.Interface;
using CropDealApp.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using iTextSharp.text.pdf;
using System.IO;
using iTextSharp.text;
using CropDealApp.Service;


namespace CropDealApp.Repository
{
    public class DealerRepository : IDealerRL
    {
        private readonly UserManager<IdentityUser> userManager;
        private readonly CropDealContext dbContext;
        private readonly ILogger<DealerRepository> _logger;
        private readonly InvoiceService _invoiceService;

        public DealerRepository(UserManager<IdentityUser> userManager, CropDealContext dbContext, ILogger<DealerRepository> logger, InvoiceService invoiceService)
        {
            this.userManager = userManager;
            this.dbContext = dbContext;
            this._logger = logger;
            _invoiceService = invoiceService;
        }

        public bool AddSubscription(Guid cropId, string email)
        {
            var user = userManager.FindByEmailAsync(email).Result;
            if (user == null)
            {
                _logger.LogWarning($"User not found for email: {email}");
                return false;
            }

            var newSubs = new Subscription
            {
                Subscription_Id = Guid.NewGuid(),
                UserId_Dealer = user.Id,
                Crop_Id = cropId,
                CreatedOn = DateTime.Now
            };

            dbContext.Subscriptions.Add(newSubs);
            dbContext.SaveChanges();
            _logger.LogInformation($"Subscription added for {user.Id}, cropId: {cropId}");
            return true;
        }

        public List<Subscription> GetAllSubscriptions(string email)
        {
            var user = userManager.FindByEmailAsync(email).Result;
            if (user == null)
            {
                _logger.LogWarning($"User not found for email: {email}");
                return null;
            }

            List<Subscription> subs = dbContext.Subscriptions.Where(c => c.UserId_Dealer == user.Id).ToList();
            _logger.LogInformation($"Retrieved {subs.Count} subscriptions for {user.Id}");
            return subs;
        }

        public List<Crop> GetAllCrops(string email)
        {
            var user = userManager.FindByEmailAsync(email).Result;
            if (user == null)
            {
                _logger.LogWarning("User not found for email: {Email}", email);
                return null;
            }
            List<Crop> ls = dbContext.Crops.ToList();

            _logger.LogInformation($"Retrieved {ls.Count} crops");
            return ls;
        }

       
        public async Task<bool> PurchaseCrop(Guid cropId, string email)
        {
            var user = await dbContext.Users.FirstOrDefaultAsync(u => u.Email == email);
            if (user == null)
            {
                _logger.LogWarning($"User not found for {email}");
                return false;
            }
            var crop = await dbContext.Crops.FindAsync(cropId);
            if (crop == null || crop.IsSold)
            {
                _logger.LogWarning($"Either Crop not found or Crop is sold for ID: {cropId}");
                return false;
            }
            var invoice = new Invoice
            {
                Invoice_Id = Guid.NewGuid(),
                Crop_Id = cropId,
                User_IdDealer = user.Id,
                User_IdFarmer = crop.User_IdFarmer,
                Quantity = crop.QuantityInKg,
                UnitPrice = crop.Price,
                TotalAmount = crop.QuantityInKg * crop.Price,
                InvoiceDate = DateTime.Now,
                PaymentMethod = "Online",
                PaymentStatus = "Completed",
                Transaction_Id = Guid.NewGuid().ToString()
            };
            crop.IsSold = true;

            await dbContext.Invoices.AddAsync(invoice);
            dbContext.Crops.Update(crop);
            await dbContext.SaveChangesAsync();

            user.Invoice_Id = invoice.Invoice_Id;
            var farmer = await dbContext.Users.FindAsync(crop.User_IdFarmer);
            farmer.Invoice_Id = invoice.Invoice_Id;
            dbContext.Users.Update(user);
            dbContext.Users.Update(farmer);
            await dbContext.SaveChangesAsync();

            _invoiceService.GenerateInvoicePdf(invoice);

            _logger.LogInformation($"Invoice created and crop marked as sold for cropId: {cropId}, dealerId: {user.Id}");
            return true;
        }




        public async Task<List<PurchaseResponseDTO>> GetAllPurchasesAsync(string email)
        {
            var user = await userManager.FindByEmailAsync(email);
            if (user == null)
            {
                _logger.LogWarning($"User not found for email: {email}");
                return null;
            }

            var invoices = await dbContext.Invoices
                .Where(i => i.User_IdDealer == user.Id)
                .ToListAsync();

            var purchases = new List<PurchaseResponseDTO>();

            foreach (var invoice in invoices)
            {
                var crop = await dbContext.Crops.AsNoTracking().FirstOrDefaultAsync(c => c.Crop_Id == invoice.Crop_Id);
                var farmer = await userManager.FindByIdAsync(invoice.User_IdFarmer);

                if (crop != null && farmer != null)
                {
                    purchases.Add(new PurchaseResponseDTO
                    {
                        CropName = crop.CropName,
                        FarmerName = farmer.UserName,
                        CropPrice = invoice.UnitPrice,
                        Quantity = invoice.Quantity,
                        TotalAmount = invoice.TotalAmount
                    });
                }
            }

            _logger.LogInformation($"Retrieved {purchases.Count} purchases for {user.Id}");
            return purchases;
        }

        public DealerProfileDTO GetDealerProfile(string email)
        {
            var user = userManager.FindByEmailAsync(email).Result;
            if (user == null)
            {
                _logger.LogWarning($"User with email {email} not found.");
                return null;
            }

        
                var subscriptions = dbContext.Subscriptions.Where(s => s.UserId_Dealer == user.Id)
                .Select(s => new SubscriptionDTO
                {
                    SubscriptionId = s.Subscription_Id,
                    CropId = s.Crop_Id,
                    CreatedOn = s.CreatedOn
                    }).ToList();

            var bankDetails = dbContext.Banks.FirstOrDefault(b => b.User_Id == user.Id);

            var profile = new DealerProfileDTO
            {
                DealerName = user.UserName,
                Email = user.Email,
                BankDetails = bankDetails != null ? new BankDTO
                {
                    AccountHolderName = bankDetails.AccountHolderName,
                    AccountNo = bankDetails.AccountNo,
                    IFSCCode = bankDetails.IFSCCode,
                    BankName = bankDetails.BankName
                } : null,
                Subscriptions = subscriptions.Any() ? subscriptions : null
            };

            return profile;
            }

        public bool EditProfile(string email, DealerProfileDTO profileDTO)
            {
                var user = userManager.FindByEmailAsync(email).Result;
                if (user == null)
                {
                    _logger.LogWarning($"User with email {email} not found.");
                    return false;
                }

                user.UserName = string.IsNullOrEmpty(profileDTO.DealerName) ? user.UserName : profileDTO.DealerName;
                user.Email = string.IsNullOrEmpty(profileDTO.Email) ? user.Email : profileDTO.Email;
                var updateUserResult = userManager.UpdateAsync(user).Result;
                if (!updateUserResult.Succeeded)
                {
                    _logger.LogError($"Failed to update user details for {email}");
                    return false;
                }

                if (profileDTO.BankDetails != null)
                {
                    var bankDetails = dbContext.Banks.FirstOrDefault(b => b.User_Id == user.Id);
                    if (bankDetails != null)
                    {
                        bankDetails.AccountHolderName = string.IsNullOrEmpty(profileDTO.BankDetails.AccountHolderName) ? bankDetails.AccountHolderName : profileDTO.BankDetails.AccountHolderName;
                        bankDetails.AccountNo = string.IsNullOrEmpty(profileDTO.BankDetails.AccountNo) ? bankDetails.AccountNo : profileDTO.BankDetails.AccountNo;
                        bankDetails.IFSCCode = string.IsNullOrEmpty(profileDTO.BankDetails.IFSCCode) ? bankDetails.IFSCCode : profileDTO.BankDetails.IFSCCode;
                        bankDetails.BankName = string.IsNullOrEmpty(profileDTO.BankDetails.BankName) ? bankDetails.BankName : profileDTO.BankDetails.BankName;
                        dbContext.SaveChanges();
                    }
                }

                return true;
        }

        public bool AddToCart(Guid cropId, string email){      
            var user = userManager.FindByEmailAsync(email).Result;
            
            if (user == null)
            {
                _logger.LogWarning($"User not found for email: {email}");
                return false;
            }

            
            var crop = dbContext.Crops.Find(cropId);
            if (crop == null)
            {
                _logger.LogWarning($"Crop not found for ID: {cropId}");
                return false;
            }
            
            var existingCartItem=dbContext.Carts.FirstOrDefault(c=>c.CropId == cropId && c.UserIdDealer == user.Id);
            if(existingCartItem !=null){
                _logger.LogWarning($"Crop already in cart for {cropId} ");
                return false;
            }
            var cart = new Cart
            {
                CartId = Guid.NewGuid(),
                CropId = cropId,
                UserIdFarmer = crop.User_IdFarmer,
                UserIdDealer = user.Id
            };

            
            dbContext.Carts.Add(cart);
            dbContext.SaveChanges();
            _logger.LogInformation($"Crop added to cart for cropId: {cropId}, dealerId: {user.Id}");
            return true;

        }    
        public List<CartResponseDTO> GetAllCartItems(string email){
                var user =userManager.FindByEmailAsync(email).Result;
                if(user == null){  
                    _logger.LogWarning($"User not found for email: {email}");
                    return null;
                }
                var cartItems=dbContext.Carts
                .Where(c=>c.UserIdDealer == user.Id)
                .Select(c=> new CartResponseDTO{
                    Crop_Id=c.Crop.Crop_Id,
                    CropType=c.Crop.CropType,
                    CropName = c.Crop.CropName,
                    QuantityInKg = c.Crop.QuantityInKg,
                    Location = c.Crop.Location,
                    Price=c.Crop.Price,
                    IsSold=c.Crop.IsSold,
                    CreatedOn=c.Crop.CreatedOn,
                }).ToList();

                return cartItems;
        }

        public bool DeleteCartItemByCropId(Guid cropId,string email){
            var user = userManager.FindByEmailAsync(email).Result;
            if(user == null){
                _logger.LogWarning($"User not found for email: {email}");
                return false;
            }
            
            var cartItem = dbContext.Carts.FirstOrDefault(c=>c.CropId == cropId && c.UserIdDealer ==user.Id);
            if(cartItem == null){         
            _logger.LogWarning($"Cart item not found for cropId: {cropId} and user: {email}");
            return false;
            }
            dbContext.Carts
            .Remove(cartItem);
            dbContext.SaveChanges();
            
            _logger.LogInformation($"Cart item deleted for cropId: {cropId}, user: {email}");
            return true;

        }



        // RATING
        public RatingDTO AddRating(string userId, RatingDTO ratingDTO){
            var user= userManager.FindByIdAsync(userId).Result;
            if(user == null){
                return null;
            }
            var addRating= new Rating{
                Rating_Id=Guid.NewGuid(),
                RatingStar=ratingDTO.RatingStar,
                Review=ratingDTO.Review,
                CreatedOn=DateTime.Now,
                User_Id=ratingDTO.UserIdFarmer
            };
            dbContext.Ratings.Add(addRating);
            dbContext.SaveChanges();
            return ratingDTO;
        }

        public RatingDTO EditRating(string userId,RatingDTO ratingDTO){
            var user=userManager.FindByIdAsync(userId).Result;
            if(user == null){
                return null;
            }
            var editedRating= new Rating{
                RatingStar=ratingDTO.RatingStar,
                Review=ratingDTO.Review,
                CreatedOn=DateTime.Now,
                User_Id=ratingDTO.UserIdFarmer
            };
            dbContext.Ratings.Update(editedRating);
            dbContext.SaveChanges();
            return ratingDTO;
        }
        public List<Rating> GetAllRating(string email){
            var user = userManager.FindByEmailAsync(email).Result;
            if(user == null){
                return null;
            }
            List<Rating> ans=dbContext.Ratings.ToList();
            return ans;
        }
        public RatingDTO GetRatingById(Guid ratingId){
            var rating = dbContext.Ratings.FirstOrDefault(c=>c.Rating_Id == ratingId);
            if(rating == null){
                return null;
            }
            RatingDTO ratingDTO = new RatingDTO{
                RatingStar=rating.RatingStar,
                Review= rating.Review,
                UserIdFarmer=rating.User_Id
            };
            return ratingDTO;
        }
        public bool DeleteRating(Guid ratingId){
            var rating =dbContext.Ratings.FirstOrDefault(c=>c.Rating_Id == ratingId);
            if(rating == null){
                _logger.LogWarning("Rating id doesn't exist");
                return false;
            }
            dbContext.Ratings.Remove(rating);
            dbContext.SaveChanges();
            return true;

        }


    }
}
