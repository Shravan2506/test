using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CropDealApp.Data;
using CropDealApp.DTO;
using CropDealApp.Interface;
using CropDealApp.Models;
using Microsoft.AspNetCore.Identity;

namespace CropDealApp.Repository
{
    public class UserBankRepository : IUserBankRL
    {
        private readonly UserManager<IdentityUser> userManager;
        private readonly CropDealContext dbContext;
        public UserBankRepository(UserManager<IdentityUser> userManager, CropDealContext dbContext)
        {
            this.dbContext = dbContext;
            this.userManager = userManager;
        }

        public bool AddBank(BankDTO bankDTO,string email){
            var user= userManager.FindByEmailAsync(email).Result;
            if(user == null){
                return false;
            }
            var user1=dbContext.Users.FirstOrDefault(c=>c.Email==email);
            var bankAcc= new Bank{
                Bank_Id=Guid.NewGuid(),
                BankName=bankDTO.BankName,
                AccountHolderName=bankDTO.AccountHolderName,
                IFSCCode=bankDTO.IFSCCode,
                AccountNo=bankDTO.AccountNo,
                CreatedOn=DateTime.Now,
                User_Id=user.Id
            };
            user1.Bank_Id=bankAcc.Bank_Id;
            dbContext.Banks.Add(bankAcc);
            dbContext.SaveChanges();
            return true;
        }
        

        public Bank  GetBankDetails(string email){
            var user=userManager.FindByEmailAsync(email).Result;
            if(user == null){
                return null;
            }
            var result=dbContext.Banks.FirstOrDefault(c=> c.User_Id == user.Id);

            return result;

        }

        public bool DeleteBankDetails(string userId, Guid bankId){
            var bank= dbContext.Banks.FirstOrDefault(c=>c.User_Id == userId && c.Bank_Id==bankId);

            if (bank == null)
        {
            return false;
        }
 
        dbContext.Banks.Remove(bank);
        dbContext.SaveChanges();
        return true; // Crop deleted successfully
        }

        public bool EditBankDetails(string userId, BankDTO bankDTO, Guid bankId){
            var bank = dbContext.Banks.FirstOrDefault(c => c.User_Id == userId && c.Bank_Id == bankId);
            if (bank == null)
            {
                return false; // Crop not found
            }

            bank.AccountHolderName = string.IsNullOrEmpty(bankDTO.AccountHolderName) || bankDTO.AccountHolderName == "string" ? bank.AccountHolderName : bankDTO.AccountHolderName;
            bank.AccountNo = string.IsNullOrEmpty(bankDTO.AccountNo) || bankDTO.AccountNo == "string" ? bank.AccountNo : bankDTO.AccountNo;
            bank.IFSCCode = string.IsNullOrEmpty(bankDTO.IFSCCode) || bankDTO.IFSCCode == "string" ? bank.IFSCCode : bankDTO.IFSCCode;
            bank.BankName = string.IsNullOrEmpty(bankDTO.BankName) || bankDTO.BankName  == "string"? bank.BankName : bankDTO.BankName;
    
            dbContext.SaveChanges();
            return true;
 
        }
    }
}