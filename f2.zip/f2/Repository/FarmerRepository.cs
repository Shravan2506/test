using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CropDealApp.Data;
using CropDealApp.DTO;
using CropDealApp.Interface;
using CropDealApp.Models;
using Microsoft.AspNetCore.Identity;

namespace CropDealApp.Repository
{
    public class FarmerRepository : IFarmerRL
    {
        private readonly UserManager<IdentityUser> userManager;
        private readonly CropDealContext dbContext;
        private readonly ILogger<FarmerRepository> _logger;
        public FarmerRepository(UserManager<IdentityUser> userManager, CropDealContext dbContext)
        {
            this.dbContext = dbContext;
            this.userManager = userManager;
        }

        public bool AddCropRL(CropDTO cropDTO, string email)
        {
            var user = userManager.FindByEmailAsync(email).Result;
            if (user == null)
            {
                return false;
            }
            var newCrop = new Crop
            {
                Crop_Id = Guid.NewGuid(),
                CropName = cropDTO.CropName,
                CropType = cropDTO.CropType,
                CreatedOn = DateTime.Now,
                Price = cropDTO.Price,
                Location = cropDTO.Location,
                QuantityInKg = cropDTO.QuantityInKg,
                IsSold = false,
                User_IdFarmer = user.Id
            };
            dbContext.Crops.Add(newCrop);
            dbContext.SaveChanges();
            return true;
        }

            public List<Crop> GetCropRL(string email)
        {
            var user = userManager.FindByEmailAsync(email).Result;
            if (user == null)
            {
                _logger.LogWarning($"User with email {email} not found.");
                return null;
            }
            var crops = dbContext.Crops.Where(c => c.User_IdFarmer == user.Id).ToList();
            if (!crops.Any())
            {
                _logger.LogInformation($"No crops found for user {user.Id}.");
            }
            return crops;
        }


        public bool DeleteCrop(string email, Guid cropId)
        {
            var user = userManager.FindByEmailAsync(email).Result;
            if (user == null)
            {
                _logger.LogWarning($"User with email {email} not found.");
                return false;
            }
            var crop = dbContext.Crops.FirstOrDefault(c => c.User_IdFarmer == user.Id && c.Crop_Id == cropId);
            if (crop == null)
            {
                _logger.LogInformation($"Crop with ID {cropId} not found for user {user.Id}.");
                return false;
            }
            dbContext.Crops.Remove(crop);
            dbContext.SaveChanges();
            return true;
        }

        public bool EditCrop(string userId, CropDTO cropDTO, Guid cropId){
            var crop = dbContext.Crops.FirstOrDefault(c => c.User_IdFarmer == userId && c.Crop_Id == cropId);
            if (crop == null)
            {
                return false;
            }
    
            crop.CropName = string.IsNullOrEmpty(cropDTO.CropName) || cropDTO.CropName == "string" ? crop.CropName : cropDTO.CropName;
            crop.CropType = string.IsNullOrEmpty(cropDTO.CropType) || cropDTO.CropType == "string" ? crop.CropType : cropDTO.CropType;
            crop.Location = string.IsNullOrEmpty(cropDTO.Location) || cropDTO.Location == "string" ? crop.Location : cropDTO.Location;
            crop.Price = cropDTO.Price == 0 ? crop.Price : cropDTO.Price;
            crop.QuantityInKg = cropDTO.QuantityInKg == 0 ? crop.QuantityInKg : cropDTO.QuantityInKg;
    
            dbContext.SaveChanges();
            return true;
    
        }

        public FarmerProfileDTO GetFarmerProfile(string email)
        {
            var user = userManager.FindByEmailAsync(email).Result;
            if (user == null)
            {
                _logger.LogWarning($"User with email {email} not found.");
                return null;
            }

            var crops = dbContext.Crops.Where(c => c.User_IdFarmer == user.Id)
                .Select(c => new CropDTO
                {
                    CropName = c.CropName,
                    CropType = c.CropType,
                    QuantityInKg = c.QuantityInKg,
                    Location = c.Location,
                    Price = c.Price
                }).ToList();

            var bankDetails = dbContext.Banks.FirstOrDefault(b => b.User_Id == user.Id);

            var profile = new FarmerProfileDTO
            {
                FarmerName = user.UserName,
                Email = user.Email,
                BankDetails = bankDetails != null ? new BankDTO
                {
                    AccountHolderName = bankDetails.AccountHolderName,
                    AccountNo = bankDetails.AccountNo,
                    IFSCCode = bankDetails.IFSCCode,
                    BankName = bankDetails.BankName
                } : null,
                Crops = crops.Any() ? crops : null
            };

            return profile;
        }

        public bool EditProfile(string email, FarmerProfileDTO profileDTO){
            var user =userManager.FindByEmailAsync(email).Result;
                

            if (user == null)
            {
                _logger.LogWarning($"User with email {email} not found.");
                return false;
            }            
            user.UserName = string.IsNullOrEmpty(profileDTO.FarmerName) ? user.UserName : profileDTO.FarmerName;
            user.Email = string.IsNullOrEmpty(profileDTO.Email) ? user.Email : profileDTO.Email;
            var updateUserResult = userManager.UpdateAsync(user).Result; 
            if (!updateUserResult.Succeeded)
            {
                _logger.LogError($"Failed to update user details for {email}");
                return false;
            }

            
    if (profileDTO.BankDetails != null)
    {
        var bankDetails = dbContext.Banks.FirstOrDefault(b => b.User_Id == user.Id);
        if (bankDetails != null)
            bankDetails.AccountHolderName = string.IsNullOrEmpty(profileDTO.BankDetails.AccountHolderName) ? bankDetails.AccountHolderName : profileDTO.BankDetails.AccountHolderName;
            
            bankDetails.AccountNo = string.IsNullOrEmpty(profileDTO.BankDetails.AccountNo) ? bankDetails.AccountNo : profileDTO.BankDetails.AccountNo;
            bankDetails.IFSCCode = string.IsNullOrEmpty(profileDTO.BankDetails.IFSCCode) ? bankDetails.IFSCCode : profileDTO.BankDetails.IFSCCode;

            bankDetails.BankName = string.IsNullOrEmpty(profileDTO.BankDetails.BankName) ? bankDetails.BankName : profileDTO.BankDetails.BankName;
            dbContext.SaveChanges();


    }

    return true;

    }


    }
}
