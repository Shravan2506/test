using System;
using System.Linq;
using System.Threading.Tasks;
using CropDealApp.Data;
using CropDealApp.DTO;
using CropDealApp.Interface;
using CropDealApp.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;

namespace CropDealApp.Repository
{
    public class UserRepository : IUser
    {
        private readonly CropDealContext _dbContext;
        private readonly UserManager<IdentityUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly ILogger<UserRepository> _logger;

        public UserRepository(ILogger<UserRepository> logger, CropDealContext dbContext, UserManager<IdentityUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            _dbContext = dbContext;
            _userManager = userManager;
            _roleManager = roleManager;
            _logger = logger;
        }

        public async Task<User> Register(SignUpDTO registerDTO)
        {
            try
            {
                var existingUser = await _userManager.FindByEmailAsync(registerDTO.Email);
                if (existingUser != null)
                {
                    _logger.LogError($"User with email {registerDTO.Email} already exists.");
                    throw new InvalidOperationException("Email already in use.");
                }

                var newUser = new User
                {
                    UserName = registerDTO.UserName,
                    Email = registerDTO.Email,
                    IsActive = true,
                    CreatedOn = DateTime.UtcNow,
                };

                var result = await _userManager.CreateAsync(newUser, registerDTO.password);
                if (result.Succeeded)
                {
                    await _userManager.AddToRoleAsync(newUser, registerDTO.Role);
                    return newUser;
                }

                _logger.LogError($"Error occurred during signup: {string.Join(", ", result.Errors.Select(e => e.Description))}");
                throw new InvalidOperationException("Signup failed.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred during registration");
                throw;
            }
        }

        public async Task<User> Login(LoginDTO loginDTO)
        {
            try
            {
                var user = await _userManager.FindByEmailAsync(loginDTO.Email);
                if (user != null && await _userManager.CheckPasswordAsync(user, loginDTO.Password))
                {
                    return new User { UserName = user.UserName, Email = user.Email, Id = user.Id };
                }

                _logger.LogError($"Invalid login attempt for email {loginDTO.Email}");
                throw new InvalidOperationException("Invalid login credentials.");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred during login");
                throw;
            }
        }
    }
}
