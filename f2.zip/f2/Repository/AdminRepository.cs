using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CropDealApp.Data;
using CropDealApp.Interface;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;

namespace CropDealApp.Repository
{
    public class AdminRepository : IAdminRL
    {
        private readonly UserManager<IdentityUser> userManager;
        private readonly CropDealContext dbContext;
        private readonly ILogger<AdminRepository> _logger;

        public AdminRepository(UserManager<IdentityUser> userManager, CropDealContext dbContext, ILogger<AdminRepository> logger)
        {
            this._logger = logger;
            this.dbContext = dbContext;
            this.userManager = userManager;
        }

        public List<IdentityUser> GetAllUsers()
        {
            try
            {
                var adminRoleId = "21de2c35-21ad-419e-8478-91c0b15a80f5"; // Admin role ID
                var users = userManager.Users.ToList();
                var adminUsers = userManager.GetUsersInRoleAsync("Admin").Result.Select(u => u.Id).ToList();
                var nonAdminUsers = users.Where(u => !adminUsers.Contains(u.Id)).ToList();
                return nonAdminUsers;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while fetching all users.");
                throw;
            }
        }

        public async Task<bool> DeleteUser(string userId, string currUserId, string role)
        {
            try
            {
                var user = await userManager.FindByIdAsync(userId);
                if (user == null)
                {
                    _logger.LogError($"User with ID {userId} not found.");
                    return false;
                }

                var isFarmer = await userManager.IsInRoleAsync(user, "Farmer");
                var isDealer = await userManager.IsInRoleAsync(user, "Dealer");

                if (isFarmer)
                {
                    var banks = dbContext.Banks.Where(c => c.User_Id == userId).ToList();
                    foreach (var bank in banks)
                    {
                        dbContext.Banks.Remove(bank);
                    }
                    var crops = dbContext.Crops.Where(c => c.User_IdFarmer == userId).ToList();
                    foreach (var crop in crops)
                    {
                        dbContext.Crops.Remove(crop);
                    }
                }

                if (isDealer)
                {
                    var banks = dbContext.Banks.Where(c => c.User_Id == userId).ToList();
                    foreach (var bank in banks)
                    {
                        dbContext.Banks.Remove(bank);
                    }
                    var subscriptions = dbContext.Subscriptions.Where(c => c.UserId_Dealer == userId).ToList();
                    foreach (var subscription in subscriptions)
                    {
                        dbContext.Subscriptions.Remove(subscription);
                    }
                }

                var ratings = dbContext.Ratings.Where(c => c.User_Id == userId).ToList();
                foreach (var rating in ratings)
                {
                    dbContext.Ratings.Remove(rating);
                }

                var result = await userManager.DeleteAsync(user);
                dbContext.SaveChanges();
                return result.Succeeded;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while deleting user.");
                throw;
            }
        }

        public (string, bool) ActivateAccount(string userId)
        {
            try
            {
                var user = dbContext.Users.FirstOrDefault(c => c.Id == userId);
                if (user == null)
                {
                    _logger.LogError($"User with ID {userId} not found.");
                    return ("User not found", false);
                }

                var isAdmin = userManager.IsInRoleAsync(user, "Admin").Result;
                if (isAdmin)
                {
                    _logger.LogError($"Attempt to activate/deactivate admin account with ID {userId}.");
                    return ("Admin account cannot be activated or deactivated", false);
                }

                if (user.IsActive)
                {
                    _logger.LogInformation($"User account with ID {userId} is already activated.");
                    return ("User account is already activated", false);
                }

                user.IsActive = true;
                dbContext.SaveChanges();
                _logger.LogInformation($"User account with ID {userId} activated successfully.");
                return ($"{user.UserName} account activated", true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while activating account.");
                throw;
            }
        }

        public (string, bool) DeactivateAccount(string userId)
        {
            try
            {
                var user = dbContext.Users.FirstOrDefault(c => c.Id == userId);
                if (user == null)
                {
                    _logger.LogError($"User with ID {userId} not found.");
                    return ("User not found", false);
                }

                var isAdmin = userManager.IsInRoleAsync(user, "Admin").Result;
                if (isAdmin)
                {
                    _logger.LogError($"Attempt to activate/deactivate admin account with ID {userId}.");
                    return ("Admin account cannot be activated or deactivated", false);
                }

                if (!user.IsActive)
                {
                    _logger.LogInformation($"User account with ID {userId} is already deactivated.");
                    return ("User account is already deactivated", false);
                }

                user.IsActive = false;
                dbContext.SaveChanges();
                _logger.LogInformation($"User account with ID {userId} deactivated successfully.");
                return ($"{user.UserName} account deactivated", true);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error occurred while deactivating account.");
                throw;
            }
        }
    }
}
