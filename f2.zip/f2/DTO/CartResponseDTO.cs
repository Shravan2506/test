using System;

namespace CropDealApp.DTO
{
    public class CartResponseDTO
    {
        public Guid Crop_Id { get; set; }
        public string CropType { get; set; }
        public string CropName { get; set; }
        public decimal QuantityInKg { get; set; }
        public string Location { get; set; }
        public bool IsSold { get; set; }
        public decimal Price { get; set; }
        public DateTime CreatedOn { get; set; }
    }
}
