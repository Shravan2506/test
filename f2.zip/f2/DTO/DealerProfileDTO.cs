using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CropDealApp.DTO
{
    public class DealerProfileDTO
    {
        
        public string DealerName { get; set; }
        public string Email { get; set; }
        public BankDTO BankDetails { get; set; }
        public List<SubscriptionDTO> Subscriptions { get; set; }

    }

    
    public class SubscriptionDTO
    {
        public Guid SubscriptionId { get; set; }
        public Guid CropId { get; set; }
        public DateTime CreatedOn { get; set; }

    }

}