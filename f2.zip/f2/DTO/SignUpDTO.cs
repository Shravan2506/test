using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CropDealApp.DTO
{
    public class SignUpDTO
    {
        public string UserName { get; set; }
        
        [EmailAddress]
        [Required]
        public string Email { get; set; }
        [Required]
        public string password { get; set; }

        // DO I need to create roles list
        
        [Required]
        public string Role { get; set; } 

    }
}