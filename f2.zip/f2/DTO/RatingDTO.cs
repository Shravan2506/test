using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Net.NetworkInformation;
using System.Threading.Tasks;

namespace CropDealApp.DTO
{
    public class RatingDTO
    {
        [Required]
        [Range(1,5)]
        public int RatingStar{get;set;}

        [Required]
        [StringLength(1000)]
        public string Review{get;set;}

        [Required]
        public string UserIdFarmer{get;set;}

    }
}