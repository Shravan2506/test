using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CropDealApp.DTO
{
    public class CropDTO
    {
        
       public string CropName { get; set; }
        public string CropType { get; set; }
        public decimal QuantityInKg { get; set; }
        public string Location { get; set; }
        public decimal Price { get; set; }
    }
}