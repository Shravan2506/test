using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CropDealApp.DTO
{
    public class BankDTO
    {
        public string AccountHolderName { get; set; }
        public string AccountNo { get; set; }
        public string IFSCCode { get; set; }
        public string BankName { get; set; }
    }
}