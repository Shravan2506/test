using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CropDealApp.DTO
{
    public class PurchaseResponseDTO
    {
        
        public string CropName { get; set; }
        public string FarmerName { get; set; }
        public decimal CropPrice { get; set; }
        public decimal Quantity { get; set; }
        public decimal TotalAmount { get; set;}

    }
}