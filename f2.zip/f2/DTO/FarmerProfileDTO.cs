using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CropDealApp.DTO
{
    public class FarmerProfileDTO
    {    
        public string FarmerName { get; set; }
        public string Email { get; set; }
        public BankDTO BankDetails { get; set; }
        public List<CropDTO> Crops { get; set; }

    }
}