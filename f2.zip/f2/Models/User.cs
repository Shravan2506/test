using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Identity;

namespace CropDealApp.Models
{
    public class User : IdentityUser
    {
        [ForeignKey("Bank")]
        public Guid Bank_Id { get; set; } = Guid.Empty;

        public ICollection<Subscription> Subscriptions { get; set; }
        public ICollection<Rating> Ratings { get; set; }

        public ICollection<Invoice> Invoices { get; set; }
        public ICollection<Crop> Crops { get; set; }

        [Required]
        [ForeignKey("Role")]
        public Guid Role_Id { get; set; }

        public bool IsActive { get; set; }
        public DateTime CreatedOn { get; set; }

        public Guid? Invoice_Id { get; set; }
        [ForeignKey("Invoice_Id")]
        public Invoice Invoice { get; set; }
    }
}
