using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Identity;

namespace CropDealApp.Models
{
    public class Cart
    {
        [Key]
        public Guid CartId { get; set; }
        
    [Required]
    public Guid CropId { get; set; }
    public Crop Crop { get; set; }

    [Required]
    public string UserIdDealer { get; set; }
    public User Dealer { get; set; }

    [Required]
    public string UserIdFarmer { get; set; }
    public User Farmer { get; set; }

    }
}
