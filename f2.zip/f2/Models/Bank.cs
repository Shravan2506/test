using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CropDealApp.Models
{
    public class Bank
    {
    [Key]
    public Guid Bank_Id { get; set; }
 
    [Required]
    [StringLength(100)]
    public string AccountHolderName { get; set; }
 
    [Required]
    [StringLength(50)]
    public string AccountNo { get; set; }
 
    [Required]
    [StringLength(20)]
    public string IFSCCode { get; set; }
 
    [Required]
    [StringLength(100)]
    public string BankName { get; set; }
 
    public DateTime CreatedOn { get; set; }
 
    // Link with User table
    [Required]
    [ForeignKey("User")]
    public string User_Id { get; set; }
    public User User { get; set; }
    }
}