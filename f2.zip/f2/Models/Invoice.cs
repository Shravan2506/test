using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CropDealApp.Models
{
    public class Invoice
    {
        [Key]
        public Guid Invoice_Id { get; set; }

        [Required]
        [ForeignKey("Crop")]
        public Guid Crop_Id { get; set; }
        public Crop Crop { get; set; }

        [Required]
        [ForeignKey("User")]
        public string User_IdDealer { get; set; }
        public User Dealer { get; set; }

        [Required]
        [ForeignKey("User")]
        public string User_IdFarmer { get; set; }
        public User Farmer { get; set; }

        [Range(0, double.MaxValue)]
        public decimal Quantity { get; set; }

        [Range(0, double.MaxValue)]
        public decimal UnitPrice { get; set; }

        [Range(0, double.MaxValue)]
        public decimal TotalAmount { get; set; }

        public DateTime InvoiceDate { get; set; }

        [StringLength(50)]
        public string PaymentMethod { get; set; }

        [StringLength(50)]
        public string PaymentStatus { get; set; }

        [StringLength(100)]
        public string Transaction_Id { get; set; }
    }
}
