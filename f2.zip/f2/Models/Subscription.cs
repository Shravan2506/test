using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CropDealApp.Models
{
    public class Subscription
    {
        [Key]
        public Guid Subscription_Id {get;set;}

        [Required]
        public string UserId_Dealer {get;set;}

        [Required]
        public Guid Crop_Id {get;set;}

        [Required]
        [DataType(DataType.DateTime)]
        public DateTime CreatedOn {get;set;}
        
    }
}