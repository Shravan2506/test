using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace CropDealApp.Models
{
    public class Rating
    {
        [Key]
        public Guid Rating_Id {get;set;}

        [Required]
        [Range(1,5)]
        public int RatingStar {get;set;}

        [StringLength(500)]
        public string Review {get;set;}

        public DateTime CreatedOn {get;set;}

        [Required]
        [ForeignKey("User")]
        public string User_Id {get;set;}
        public User User{get;set;}
    }
}