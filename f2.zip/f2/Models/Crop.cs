using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;

namespace CropDealApp.Models
{
    public class Crop
    {
    [Key]
    public Guid Crop_Id { get; set; }
 
    [Required]
    [StringLength(100)]
    public string CropType { get; set; }
 
    [Required]
    [StringLength(100)]
    public string CropName { get; set; }
 
    [Range(0, double.MaxValue)]
    public decimal QuantityInKg { get; set; }
 
    [Required]
    [StringLength(200)]
    public string Location { get; set; }
 
    public bool IsSold { get; set; }
 
    [Range(0, double.MaxValue)]
    public decimal Price { get; set; }
 
    public DateTime CreatedOn { get; set; }
 
    // Link with User table for Farmer role
    [Required]
    [ForeignKey("User")]
    public string User_IdFarmer { get; set; }
    public User User { get; set; }
    }
}