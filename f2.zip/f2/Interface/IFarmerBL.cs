using CropDealApp.DTO;
using CropDealApp.Models;
using System;
using System.Collections.Generic;

namespace CropDealApp.Interface
{
    public interface IFarmerBL
    {
        bool AddCrop(CropDTO cropDTO, string email);
        List<Crop> GetCrop(string email);
        bool DeleteCrop(string userId, Guid cropId);
        bool EditCrop(string userId, CropDTO cropDTO, Guid cropId);
        FarmerProfileDTO GetFarmerProfile(string email);
        bool EditProfile(string email, FarmerProfileDTO profileDTO);
    }
}
