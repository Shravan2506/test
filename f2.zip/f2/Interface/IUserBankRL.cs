using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CropDealApp.DTO;
using CropDealApp.Models;

namespace CropDealApp.Interface
{
    public interface IUserBankRL
    {

        public bool AddBank(BankDTO bankDTO,string email);
        public Bank GetBankDetails(string email);
        public bool EditBankDetails(string userId, BankDTO bankDTO, Guid bankId);
        public bool DeleteBankDetails(string userId, Guid bankId);
        
        
    }
}