using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using CropDealApp.DTO;
using CropDealApp.Models;

namespace CropDealApp.Interface
{
    public interface IDealerBL
    {
        bool AddSubscription(Guid cropId, string email);
        List<Subscription> GetAllSubscriptions(string email);
        List<Crop> GetAllCrops(string email);
        public Task<bool> PurchaseCrop(Guid cropId, string email);
        Task<List<PurchaseResponseDTO>> GetAllPurchasesAsync(string email);
        DealerProfileDTO GetDealerProfile(string email);

        bool EditProfile(string email, DealerProfileDTO profileDTO);
        bool AddToCart(Guid cropId, string email);
        // Task<List<CropDTO>> GetAllCartItems(string dealerId);
        List<CartResponseDTO> GetAllCartItems(string email);
        bool DeleteCartItemByCropId(Guid cropId,string email);
        RatingDTO AddRating(string userId, RatingDTO ratingDTO);

        RatingDTO EditRating(string userId,RatingDTO ratingDTO);
        List<Rating> GetAllRating(string email);
        RatingDTO GetRatingById(Guid ratingId); 
        bool DeleteRating(Guid ratingId);
    }
}
