using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;

namespace CropDealApp.Interface
{
    public interface IJwtTokenHelper
    {
        string GenerateToken(string userId, string email, List<string> roles);
    }
}
