using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CropDealApp.DTO;
using CropDealApp.Models;

namespace CropDealApp.Interface
{
    public interface IUserBankBL
    {
        
        bool AddBank(BankDTO bankDTO, string email);
        Bank GetBankDetails(string email); 
        bool DeleteBankDetails(string userId, Guid bankId);
        bool EditBankDetails(string userId, BankDTO bankDTO, Guid bankId);

    }
}