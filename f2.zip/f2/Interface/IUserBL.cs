using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CropDealApp.DTO;
using CropDealApp.Models;

namespace CropDealApp.Interface
{
    public interface IUserBL
    {
        Task<User> RegisterBL(SignUpDTO signUpDto);
        Task<(User user, string token)> LoginBL(LoginDTO loginDto);
    }
}