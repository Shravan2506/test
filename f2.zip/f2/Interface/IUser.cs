using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using CropDealApp.DTO;
using CropDealApp.Models;

namespace CropDealApp.Interface
{
    public interface IUser
    {
        
        Task<User> Register(SignUpDTO signUpDto);
        Task<User> Login(LoginDTO loginDto);

    }
}