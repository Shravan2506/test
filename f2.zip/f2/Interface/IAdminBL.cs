using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;

namespace CropDealApp.Interface
{
    public interface IAdminBL
    {
        List<IdentityUser> GetAllUsers();
        Task<bool> DeleteUser(string userId, string currUserId,string role);
        (string, bool) ActivateAccount(string userId);
        (string,bool) DeactivateAccount(string userId);

    }
}